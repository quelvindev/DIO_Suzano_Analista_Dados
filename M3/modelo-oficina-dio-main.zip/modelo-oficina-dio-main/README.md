
# Modelagem Banco de Dados – E-COMMERCE :bookmark_tabs:

  

## - Atualizando modelagem para app gerador de Ordem de Serviço solicitado do desafio DIO

- Modelo_Oficina2.0.png

- Modelo_Oficina2.0.mwb
## - Criação do banco
- create_database.sql 
## - Criação dos inserts e consultas

  
  
  
  
  

  

Por [Quelvin Carvalho](https://www.linkedin.com/in/quelvin-carvalho-5b9b40102/)

Arquivo está disponibilizado no [Github](https://github.com/Quelvin/modelo-oficina-dio.git) :file_folder: